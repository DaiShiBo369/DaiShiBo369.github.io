# Windows 可运行程序

这里放置 Windows 10 64 位可运行程序包。

要求：

- 包含 `StarRingDefense.exe`。
- 包含运行所需的 Qt DLL 和平台插件目录。
- 建议使用与编译器匹配的 `windeployqt` 部署后，再从本目录双击测试。
